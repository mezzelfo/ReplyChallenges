https://www.muppetlabs.com/~breadbox/software/tiny/return42.html
https://www.muppetlabs.com/~breadbox/software/tiny/useless.html
https://www.muppetlabs.com/~breadbox/software/tiny/useful.html
